>>>>>>>>>>>>>>>>Image Mamagement Tool<<<<<<<<<<<<<<<<<<<

///////////////////////////

University - NIBM
Assignment - PDSA
Language - Java
IDE - intellij


///////////////////////////

COHNDSE241F-044 A W W A M D Gunawardena 
COHNDSE241F-100 R B L Rajasinghe 
COHNDSE241F-101 D R C M T Dissanayake 
COHNDSE241F-102 G A P S Chamuditha

//////////////////////////

These are the Project Files for PDSA assignment.
Target is to make simple  image management Tool with a Few Data Stuctures and algorithm.
